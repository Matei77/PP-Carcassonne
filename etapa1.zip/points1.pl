
vmpoints(Test, Points):-
        member(Test:Points,
               [
                          at:15
                        , atL:15
                        , c2:5
                        , ccw:15
                        , rot:30
                        , match:10
                        , findrot:30
              ]).
